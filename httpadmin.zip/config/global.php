<?php

return [

    'url' => 'http://restschool.hridham.com/api',
    'storage'=>'http://restschool.hridham.com/storage'

]

?>
