<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h2>Album Details</h2>
<div class="card">
    <div class="card-body">
        <ul>
        @foreach ( $albums as $album)
        <li>{{  $album['album_name'] }}</li>
        <li>{{  $album['album_date'] }}</li>
        <li>
            <img src="{{ config('global.storage').'/cover_pictures/' .$album['cover_picture'] }}" height="100px" width="150px" alt="" sizes="small">
       </li>
        <li>{{ $album['album_venue'] }}</li>
        <li>{{ $album['privacy'] }}</li>
        <li>{{ $album['created_at']  }}</li>
        <li>{{ $album['updated_at']  }}</li>
        @endforeach
    </ul>
    </div>


</div>
<br>
<br>
<h2>Photos</h2>

<div>
    <table>
        <thead>
            <tr>
                <th>Type</th>
                    <th>Image</th>
                    <th>Image Descrption</th>
                    <th> Video URL</th>
                    <th>Privacy</th>
                    <th>Created At</th>
                    <th>Action</th>


            </tr>
        </thead>


        <tbody>


@if (count($photos)>0)
@foreach ( $photos as $photo)
<tr>
    <td>{{  $photo['type'] }}</td>
    <td> <img src="{{ config('global.storage').'/photos/'.$photo['photo'] }}" height="50px" width="50px" alt="">
        </td>
    <td>{{ $photo['photo_description'] }}</td>
    <td>{{ $photo['path'] }}</td>
    <td>{{ $photo['privacy'] }}</td>
    <td>{{ $photo['created_at'] }}</td>
    <td> <a href="#"> View</a>
        <a href="">Edit</a>
        <a href="">Delete</a>
    </td>
</tr>
@endforeach
@else
    {{ "No Image Uploaded" }}
@endif


</tbody>
</table>
</div>



</body>
</html>
